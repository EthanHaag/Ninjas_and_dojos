from flask import render_template, request, redirect
from flask_app.models.ninja import Ninja
from flask_app.models.dojo import Dojo
from flask_app import app

@app.route("/Dojo")
def home():
    Dojos = Dojo.get_all()
    return render_template("newDojo.html", dojos = Dojos)
@app.route("/ninjas")
def ninjas():
    Dojos = Dojo.get_all()
    return render_template("newNinja.html",dojos = Dojos)
@app.route('/createDojo', methods=['POST'])
def createDojo():
    data = {'name':request.form['name']}
    Dojo.save(data)
    return redirect('/Dojo')
@app.route('/createNinja', methods=['POST'])
def createNinja():
    data = {
        'first_name':request.form['fname'],
        'last_name':request.form['lname'],
        'age':request.form['age'],
        'dojo_id':request.form['dojo']
    }
    Ninja.save(data)
    return redirect('/Dojo')
@app.route('/dojos/<int:id>')
def dojo(id):
    data = {'id':id}
    ninjasInDojo = Dojo.get_ninjas_and_dojos(data)
    print(ninjasInDojo)
    selectedDojo = Dojo.get_one(data)
    return render_template('dojos.html', dojo=selectedDojo[0], ninjas = ninjasInDojo)