
from flask_app.config.mySqlconnection import connectToMySQL
from flask_app.models.ninja import Ninja
class Dojo:
    def __init__( self , data ):
        self.id = data['id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.ninjas = []
    @classmethod
    def save( cls , data ):
        query = "INSERT INTO dojos ( name, created_at , updated_at ) VALUES (%(name)s,NOW(),NOW());"
        return connectToMySQL('ninjas_and_dojos').query_db(query,data)
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM dojos;"
        results = connectToMySQL('ninjas_and_dojos').query_db(query)
        dojos = []
        for dojo in results:
            dojos.append( cls(dojo) )
        return dojos
    @classmethod
    def get_one(cls, data):
        query = "SELECT * FROM dojos where id = %(id)s;"
        return connectToMySQL('ninjas_and_dojos').query_db(query, data)
    @classmethod
    def get_ninjas_and_dojos( cls , data ):
        query = "SELECT * FROM ninjas LEFT JOIN dojos ON ninjas.dojo_id = dojos.id WHERE dojos.id = %(id)s;"
        results = connectToMySQL('ninjas_and_dojos').query_db( query , data )
        print("results",results)
        if results == ():
            ninja_data = {
                "id" : 'none',
                "first_name" : 'none',
                "last_name" : 'none',
                "age" : 'none',
                "created_at" : 'none',
                "updated_at" : 'none'
            }
            return ninja_data
        dojos = cls( results[0] )
        for row in results:
            ninja_data = {
                "id" : row['id'],
                "first_name" : row["first_name"],
                "last_name" : row["last_name"],
                "age" : row["age"],
                "created_at" : row["created_at"],
                "updated_at" : row["updated_at"]
            }
            dojos.ninjas.append( Ninja( ninja_data ) )
        return dojos.ninjas